var calculadora = {

	Display: document.getElementById("display"),
	displayVal: "0",
	operacionVal: "",
	primerVal: 0,
	segundoVar: 0,
	ultimoVal: 0,
	resultado: 0,
	auxTeclaIgual: false,

	init: (function(){
		this.EventosBotones(".tecla");
		this.EventosdeFuncion();
	}),

	//Funcion de botones

	EventosBotones: function(select){
		var x = document.querySelectorAll(select);
		for (var i = 0; i<x.length;i++) {
			x[i].onmouseover = this.transformBoton;
			x[i].onmouseleave = this.equalBoton;
		};
	},

	transformBoton: function(event){
		calculadora.ReduceBoton(event.target);
	},

	equalBoton: function(event){
		calculadora.AumentaBoton(event.target);
	},

	//Transformacion de botones

	ReduceBoton: function(elemento){
		var x = elemento.id;
		if (x=="1" || x=="2" || x=="3" || x=="0" || x=="igual" || x=="punto" ) {
			elemento.style.width = "28%";
			elemento.style.height = "62px";
		} else if(x=="mas") {
			elemento.style.width = "88%";
			elemento.style.height = "98%";
		} else {
		elemento.style.width = "21%";
		elemento.style.height = "62px";
		}
	},

	AumentaBoton: function(elemento){
		var x = elemento.id;
		if (x=="1" || x=="2" || x=="3" || x=="0" || x=="igual" || x=="punto" ) {
			elemento.style.width = "29%";
			elemento.style.height = "62.91px";
		} else if(x=="mas") {
			elemento.style.width = "90%";
			elemento.style.height = "100%";
		} else {
		elemento.style.width = "22%";
		elemento.style.height = "62.91px";
		}
	},

	EventosdeFuncion: function(){
		document.getElementById("0").addEventListener("click", function() {calculadora.ingresoNumero("0");});
		document.getElementById("1").addEventListener("click", function() {calculadora.ingresoNumero("1");});
		document.getElementById("2").addEventListener("click", function() {calculadora.ingresoNumero("2");});
		document.getElementById("3").addEventListener("click", function() {calculadora.ingresoNumero("3");});
		document.getElementById("4").addEventListener("click", function() {calculadora.ingresoNumero("4");});
		document.getElementById("5").addEventListener("click", function() {calculadora.ingresoNumero("5");});
		document.getElementById("6").addEventListener("click", function() {calculadora.ingresoNumero("6");});
		document.getElementById("7").addEventListener("click", function() {calculadora.ingresoNumero("7");});
		document.getElementById("8").addEventListener("click", function() {calculadora.ingresoNumero("8");});
		document.getElementById("9").addEventListener("click", function() {calculadora.ingresoNumero("9");});
		document.getElementById("on").addEventListener("click", function() {calculadora.borrarVisor();});
		document.getElementById("sign").addEventListener("click", function() {calculadora.cambiarSigno();});
		document.getElementById("punto").addEventListener("click", function() {calculadora.ingresoDecimal();});
		document.getElementById("igual").addEventListener("click", function() {calculadora.verResultado();});
		document.getElementById("dividido").addEventListener("click", function() {calculadora.ingresoOperacion("/");});
		document.getElementById("por").addEventListener("click", function() {calculadora.ingresoOperacion("*");});
		document.getElementById("menos").addEventListener("click", function() {calculadora.ingresoOperacion("-");});
		document.getElementById("mas").addEventListener("click", function() {calculadora.ingresoOperacion("+");});
	},

	borrarVisor: function(){

	  this.displayVal = "0";
		this.operacion = "";
		this.primerVal = 0;
		this.segundoVar = 0;
		this.resultado = 0;
		this.Operación = "";
		this.auxTeclaIgual = false;
		this.ultimoVal = 0;
		this.updateDisplay();
	},

	cambiarSigno: function(){
		if (this.displayVal !="0") {
			var aux;
			if (this.displayVal.charAt(0)=="-") {
				aux = this.displayVal.slice(1);
			}	else {
				aux = "-" + this.displayVal;
			}
		this.displayVal = "";
		this.displayVal = aux;
		this.updateDisplay();
		}
	},

	ingresoDecimal: function(){
		if (this.displayVal.indexOf(".")== -1) {
			if (this.displayVal == ""){
				this.displayVal = this.displayVal + "0.";
			} else {
				this.displayVal = this.displayVal + ".";
			}
			this.updateDisplay();
		}
	},

	ingresoNumero: function(valor){
		if (this.displayVal.length < 8) {

			if (this.displayVal=="0") {
				this.displayVal = "";
				this.displayVal = this.displayVal + valor;
			} else {
				this.displayVal = this.displayVal + valor;
			}
		this.updateDisplay();
		}
	},

	ingresoOperacion: function(oper){
		this.primerVal = parseFloat(this.displayVal);
		this.displayVal = "";
		this.operacion = oper;
		this.auxTeclaIgual = false;
		this.updateDisplay();
	},

	verResultado: function(){

		if(!this.auxTeclaIgual){
			this.segundoVal = parseFloat(this.displayVal);
			this.ultimoVal = this.segundoVal;
			this.realizarOperacion(this.primerVal, this.segundoVal, this.operacion);

		} else {
			this.realizarOperacion(this.primerVal, this.ultimoVal, this.operacion);
		}

		this.primerVal = this.resultado;
		this.displayVal = "";

		if (this.resultado.toString().length < 9){
			this.displayVal = this.resultado.toString();
		} else {
			this.displayVal = this.resultado.toString().slice(0,8) + "...";
		}

		this.auxTeclaIgual = true;
		this.updateDisplay();

	},

	realizarOperacion: function(primerVal, segundoVal, operacion){
		switch(operacion){
			case "+":
				this.resultado = eval(primerVal + segundoVal);
			break;
			case "-":
				this.resultado = eval(primerVal - segundoVal);
			break;
			case "*":
				this.resultado = eval(primerVal * segundoVal);
			break;
			case "/":
				this.resultado = eval(primerVal / segundoVal);
			break;

		}
	},

   updateDisplay: function(){
		this.Display.innerHTML = this.displayVal;
	}

};

calculadora.init();
